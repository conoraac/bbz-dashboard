// Vercel serverless entry — reuses the same Express app.
import app from '../server.js';
export default app;
